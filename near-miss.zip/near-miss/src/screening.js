/* Near Miss — all-on-all conjunction screening.
 *
 * Finds every pair of catalogued objects that passes within `threshold` km
 * of each other inside a time window. Brute force would be n^2 / 2 pair
 * checks per time step (126 million for 15,900 objects), so the screener
 * works in three stages:
 *
 *   1. PROPAGATE  every object to the step time with SGP4 (position + velocity).
 *   2. BROAD PHASE  bin positions into a uniform 3-D grid whose cell edge is
 *      threshold + vMax * step. Two objects that could come within the
 *      threshold during this step must sit in the same or adjacent cells, so
 *      only those pairs are examined. The grid is an open-addressing hash
 *      table held in typed arrays: no allocation per step.
 *   3. NARROW PHASE  for each surviving pair, solve for the time of closest
 *      approach (TCA) assuming straight-line relative motion across the step,
 *      then re-propagate both objects at that time and solve again. The second
 *      pass removes the curvature error of the first.
 *
 * The screener is incremental: call run(budgetMs) from an animation frame and
 * it does as much work as fits, so the UI never blocks.
 */
(function (root) {
  'use strict';
  const sat = root.satellite || (typeof require === 'function' ? require('satellite.js') : null);

  const V_MAX = 15.6;                 // km/s, head-on LEO closing speed upper bound
  const TABLE_BITS = 16;
  const TABLE_SIZE = 1 << TABLE_BITS; // must stay > 2x the object count
  const EMPTY = -1;

  class Screener {
    /**
     * @param {Array} sats         catalogue from NM.catalog.parseCatalogue
     * @param {object} opt
     * @param {number} opt.startMs      window start (unix ms)
     * @param {number} opt.windowS      window length, seconds
     * @param {number} [opt.stepS=10]   coarse step, seconds
     * @param {number} [opt.threshold=5]  miss distance to report, km
     * @param {number} [opt.minRelSpeed=0.1]  km/s; slower pairs are formation
     *        flying or docked and are counted, not reported
     * @param {function} [opt.onEvent]  called with each new or improved event
     */
    constructor(sats, opt) {
      this.sats = sats;
      this.n = sats.length;
      this.startMs = opt.startMs;
      this.stepS = opt.stepS || 10;
      this.steps = Math.ceil(opt.windowS / this.stepS);
      this.threshold = opt.threshold || 5;
      this.minRelSpeed = opt.minRelSpeed == null ? 0.1 : opt.minRelSpeed;
      this.onEvent = opt.onEvent || null;
      this.cell = this.threshold + V_MAX * this.stepS;

      const n = this.n;
      this.pos = new Float64Array(n * 3);
      this.vel = new Float64Array(n * 3);
      this.ok = new Uint8Array(n);
      this.cx = new Int32Array(n); this.cy = new Int32Array(n); this.cz = new Int32Array(n);
      this.next = new Int32Array(n);
      this.tabKey = new Int32Array(TABLE_SIZE);
      this.tabHead = new Int32Array(TABLE_SIZE);

      this.step = 0;          // current coarse step
      this.cursor = 0;        // next object to propagate within the step
      this.done = false;
      this.events = new Map();    // pairKey -> event (closest pass per pair)
      this.coOrbiting = new Set();
      this.stats = { propagations: 0, pairsTested: 0, refinements: 0 };
    }

    get progress() { return this.done ? 1 : (this.step + this.cursor / this.n) / this.steps; }
    get scannedToMs() { return this.startMs + this.step * this.stepS * 1000; }

    /** Minutes since a satellite's TLE epoch for a unix-ms time. */
    static tsince(rec, ms) { return (ms / 86400000 + 2440587.5 - rec.jdsatepoch) * 1440; }

    /** Do up to `budgetMs` of work. Returns true when the window is finished. */
    run(budgetMs) {
      const t0 = now();
      while (!this.done) {
        if (!this._propagateSome(t0, budgetMs)) return false;
        this._broadPhase();
        this.step++; this.cursor = 0;
        if (this.step >= this.steps) this.done = true;
        if (now() - t0 > budgetMs) break;
      }
      return this.done;
    }

    _propagateSome(t0, budgetMs) {
      const { sats, pos, vel, ok, n } = this;
      const ms = this.startMs + this.step * this.stepS * 1000;
      let i = this.cursor;
      while (i < n) {
        const end = Math.min(n, i + 512);
        for (; i < end; i++) {
          const rec = sats[i].rec;
          const pv = sat.sgp4(rec, Screener.tsince(rec, ms));
          const p = pv.position, v = pv.velocity;
          if (!p || !v || !isFinite(p.x)) { ok[i] = 0; continue; }
          ok[i] = 1;
          const k = i * 3;
          pos[k] = p.x; pos[k + 1] = p.y; pos[k + 2] = p.z;
          vel[k] = v.x; vel[k + 1] = v.y; vel[k + 2] = v.z;
        }
        this.stats.propagations += 512;
        if (i < n && now() - t0 > budgetMs) { this.cursor = i; return false; }
      }
      this.cursor = n;
      return true;
    }

    _hash(ix, iy, iz) {
      // Pack three signed cell indices (|i| < 512 covers +/- 80,000 km) into 30 bits.
      return ((ix + 512) | ((iy + 512) << 10) | ((iz + 512) << 20)) | 0;
    }

    _slot(key) {
      const { tabKey } = this;
      let s = Math.imul(key, 0x9E3779B1) >>> (32 - TABLE_BITS);
      while (tabKey[s] !== EMPTY && tabKey[s] !== key) s = (s + 1) & (TABLE_SIZE - 1);
      return s;
    }

    _broadPhase() {
      const { n, pos, ok, cx, cy, cz, next, tabKey, tabHead, cell } = this;
      tabKey.fill(EMPTY);
      const inv = 1 / cell;
      for (let i = 0; i < n; i++) {
        if (!ok[i]) continue;
        const k = i * 3;
        const ix = Math.floor(pos[k] * inv), iy = Math.floor(pos[k + 1] * inv), iz = Math.floor(pos[k + 2] * inv);
        if (ix < -511 || ix > 510 || iy < -511 || iy > 510 || iz < -511 || iz > 510) { ok[i] = 0; continue; }
        cx[i] = ix; cy[i] = iy; cz[i] = iz;
        const key = this._hash(ix, iy, iz);
        const s = this._slot(key);
        if (tabKey[s] === EMPTY) { tabKey[s] = key; next[i] = EMPTY; } else next[i] = tabHead[s];
        tabHead[s] = i;
      }
      // Visit each object's own cell plus the 26 neighbours; j > i keeps pairs unique.
      for (let i = 0; i < n; i++) {
        if (!ok[i]) continue;
        const ix = cx[i], iy = cy[i], iz = cz[i];
        for (let dx = -1; dx <= 1; dx++) for (let dy = -1; dy <= 1; dy++) for (let dz = -1; dz <= 1; dz++) {
          const key = this._hash(ix + dx, iy + dy, iz + dz);
          const s = this._slot(key);
          if (tabKey[s] === EMPTY) continue;
          for (let j = tabHead[s]; j !== EMPTY; j = next[j]) if (j > i) this._narrowPhase(i, j);
        }
      }
    }

    _narrowPhase(i, j) {
      const { pos, vel, stepS, threshold } = this;
      const a = i * 3, b = j * 3;
      const rx = pos[b] - pos[a], ry = pos[b + 1] - pos[a + 1], rz = pos[b + 2] - pos[a + 2];
      const vx = vel[b] - vel[a], vy = vel[b + 1] - vel[a + 1], vz = vel[b + 2] - vel[a + 2];
      this.stats.pairsTested++;
      const vv = vx * vx + vy * vy + vz * vz;
      let tca = vv > 1e-12 ? -(rx * vx + ry * vy + rz * vz) / vv : 0;
      // A minimum outside [0, step) belongs to a neighbouring step.
      if (tca < 0 || tca >= stepS) return;
      const mx = rx + vx * tca, my = ry + vy * tca, mz = rz + vz * tca;
      const d2 = mx * mx + my * my + mz * mz;
      const lim = threshold + 1.5;                   // slack for curvature before refinement
      if (d2 > lim * lim) return;
      this._refine(i, j, this.startMs + (this.step * stepS + tca) * 1000);
    }

    /** Re-propagate both objects at the estimated TCA and solve once more. */
    _refine(i, j, ms) {
      const A = this.sats[i], B = this.sats[j];
      let pa, pb, d = Infinity, rel = 0;
      for (let pass = 0; pass < 2; pass++) {
        pa = sat.sgp4(A.rec, Screener.tsince(A.rec, ms));
        pb = sat.sgp4(B.rec, Screener.tsince(B.rec, ms));
        if (!pa.position || !pb.position) return;
        const rx = pb.position.x - pa.position.x, ry = pb.position.y - pa.position.y, rz = pb.position.z - pa.position.z;
        const vx = pb.velocity.x - pa.velocity.x, vy = pb.velocity.y - pa.velocity.y, vz = pb.velocity.z - pa.velocity.z;
        const vv = vx * vx + vy * vy + vz * vz;
        rel = Math.sqrt(vv);
        const dt = vv > 1e-12 ? -(rx * vx + ry * vy + rz * vz) / vv : 0;
        const mx = rx + vx * dt, my = ry + vy * dt, mz = rz + vz * dt;
        d = Math.sqrt(mx * mx + my * my + mz * mz);
        ms += dt * 1000;
      }
      this.stats.refinements++;
      if (d > this.threshold) return;
      const key = i * 65536 + j;
      if (rel < this.minRelSpeed) { this.coOrbiting.add(key); return; }
      const prev = this.events.get(key);
      if (prev && prev.miss <= d) return;
      const ev = {
        key, a: i, b: j,
        tcaMs: ms,
        miss: d,                       // km
        relSpeed: rel,                 // km/s
        // TEME midpoint at TCA; the UI rotates it into the Earth-fixed frame.
        mid: [(pa.position.x + pb.position.x) / 2, (pa.position.y + pb.position.y) / 2, (pa.position.z + pb.position.z) / 2],
      };
      this.events.set(key, ev);
      if (this.onEvent) this.onEvent(ev, !prev);
    }

    /** Events sorted by time of closest approach. */
    list() { return Array.from(this.events.values()).sort((x, y) => x.tcaMs - y.tcaMs); }
  }

  function now() { return (typeof performance !== 'undefined' ? performance : Date).now(); }

  const api = { Screener };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.NM = Object.assign(root.NM || {}, { screening: api });
})(typeof window !== 'undefined' ? window : globalThis);
