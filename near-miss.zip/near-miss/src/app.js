/* Near Miss — application: clock, position snapshots, selection and UI. */
(function (root) {
  'use strict';
  const { parseCatalogue, RE } = NM.catalog;
  const { Screener } = NM.screening;
  const COLORS = NM.COLORS;
  const DEG = Math.PI / 180;
  const $ = (id) => document.getElementById(id);

  const WINDOW_S = 3 * 3600;          // how far ahead to screen
  const THRESHOLD_KM = 5;             // widest miss distance kept
  const LIVE_SOURCE = 'https://celestrak.org/NORAD/elements/gp.php?GROUP=active&FORMAT=tle';

  const state = {
    sats: [], n: 0, epochMs: 0, source: 'snapshot',
    groups: null,
    clock: { base: Date.now(), real: performance.now(), speed: 1 },
    snap: null,
    cur: null, trailBuf: null, tx: null, ty: null,
    screener: null,
    shown: [],                        // events currently drawn as markers
    maxMiss: 1,                       // list / marker filter, km
    sort: 'soonest',
    sel: null,                        // {type:'event'|'sat', ...}
    listDirty: true,
    interacted: false,
    anim: null,
    hover: -1,
  };
  let globe;

  // ---------------------------------------------------------------- time
  const simNow = () => state.clock.base + (performance.now() - state.clock.real) * state.clock.speed;
  function setClock(ms, speed) {
    state.clock = { base: ms, real: performance.now(), speed };
    state.snap = null;                                  // force a fresh pair of snapshots
    document.querySelectorAll('[data-speed]').forEach((b) => b.setAttribute('aria-pressed', String(+b.dataset.speed === speed)));
    state.listDirty = true;
  }
  const isLive = () => state.clock.speed === 1 && Math.abs(simNow() - Date.now()) < 1500;
  const gmstAt = (ms) => satellite.gstime(new Date(ms));

  /** Sub-solar point. Good to a few degrees, which is plenty for shading. */
  function sunPoint(ms) {
    const d = new Date(ms);
    const day = (Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()) - Date.UTC(d.getUTCFullYear(), 0, 0)) / 864e5;
    const hours = d.getUTCHours() + d.getUTCMinutes() / 60 + d.getUTCSeconds() / 3600;
    return { lat: -23.44 * Math.cos(2 * Math.PI * (day + 10) / 365.24), lon: (12 - hours) * 15 };
  }

  // ------------------------------------------------- position snapshots
  // Running SGP4 for 16,000 objects every frame would eat the frame budget, so
  // positions are propagated at two times a few seconds apart and every frame
  // interpolates between them. A third snapshot is prepared a slice at a time.
  function propagateInto(buf, ms, from, to) {
    const sats = state.sats;
    for (let i = from; i < to; i++) {
      const rec = sats[i].rec;
      const p = satellite.sgp4(rec, Screener.tsince(rec, ms)).position;
      const k = i * 3;
      if (p && isFinite(p.x)) { buf[k] = p.x; buf[k + 1] = p.y; buf[k + 2] = p.z; }
      else { buf[k] = buf[k + 1] = buf[k + 2] = NaN; }
    }
  }

  function updateSnapshots(ms) {
    const n = state.n, speed = state.clock.speed;
    const delta = 4000 * Math.max(1, speed);
    let s = state.snap;
    if (!s || ms < s.tA || ms > s.tB + delta) {
      s = state.snap = s || { A: new Float32Array(n * 3), B: new Float32Array(n * 3), C: new Float32Array(n * 3) };
      s.tA = ms; s.tB = ms + delta; s.tC = s.tB + delta; s.cursor = 0;
      propagateInto(s.A, s.tA, 0, n); propagateInto(s.B, s.tB, 0, n);
    }
    if (ms > s.tB) {
      if (s.cursor < n) propagateInto(s.C, s.tC, s.cursor, n);
      const old = s.A; s.A = s.B; s.B = s.C; s.C = old;
      s.tA = s.tB; s.tB = s.tC; s.tC = s.tB + delta; s.cursor = 0;
    } else if (s.cursor < n) {
      const to = Math.min(n, s.cursor + 2500);
      propagateInto(s.C, s.tC, s.cursor, to); s.cursor = to;
    }
    return s;
  }

  /** Interpolate direction linearly and radius separately so orbits stay round. */
  function interpolate(s, ms, out) {
    const f = (ms - s.tA) / (s.tB - s.tA), g = 1 - f, A = s.A, B = s.B;
    for (let k = 0, m = state.n * 3; k < m; k += 3) {
      const ax = A[k], ay = A[k + 1], az = A[k + 2], bx = B[k], by = B[k + 1], bz = B[k + 2];
      const x = ax * g + bx * f, y = ay * g + by * f, z = az * g + bz * f;
      const ra = Math.sqrt(ax * ax + ay * ay + az * az), rb = Math.sqrt(bx * bx + by * by + bz * bz);
      const q = (ra * g + rb * f) / Math.sqrt(x * x + y * y + z * z);
      out[k] = x * q; out[k + 1] = y * q; out[k + 2] = z * q;
    }
  }

  // ------------------------------------------------------------ helpers
  function toEcef(p, gmst) {
    const c = Math.cos(gmst), s = Math.sin(gmst);
    return [p[0] * c + p[1] * s, -p[0] * s + p[1] * c, p[2]];
  }
  function geodetic(e) {
    const r = Math.hypot(e[0], e[1], e[2]);
    return { lat: Math.asin(e[2] / r) / DEG, lon: Math.atan2(e[1], e[0]) / DEG, alt: r - RE };
  }
  function exact(i, ms) {
    const rec = state.sats[i].rec;
    const pv = satellite.sgp4(rec, Screener.tsince(rec, ms));
    return pv.position ? [pv.position.x, pv.position.y, pv.position.z, pv.velocity] : null;
  }
  function orbitPoints(i, ms) {
    const s = state.sats[i], N = 180, out = new Float32Array(N * 3 + 3);
    for (let q = 0; q <= N; q++) {
      const p = exact(i, ms + (q / N - 0.5) * s.period * 60000);
      if (p) { out[q * 3] = p[0]; out[q * 3 + 1] = p[1]; out[q * 3 + 2] = p[2]; }
    }
    return out;
  }
  const fmtInt = (x) => Math.round(x).toLocaleString('en-US');
  const fmtMiss = (km) => km < 1 ? Math.round(km * 1000) + ' m' : km.toFixed(2) + ' km';
  const fmtUTC = (ms) => new Date(ms).toISOString().substring(11, 19);
  function fmtIn(dtMs) {
    const s = Math.round(dtMs / 1000);
    if (s < -20) return 'passed';
    if (s < 20) return 'now';
    if (s < 90) return 'in ' + s + ' s';
    if (s < 5400) return 'in ' + Math.round(s / 60) + ' min';
    return 'in ' + (s / 3600).toFixed(1) + ' h';
  }
  const fmtLatLon = (g) => Math.abs(g.lat).toFixed(1) + '°' + (g.lat >= 0 ? 'N' : 'S') + ' ' + Math.abs(g.lon).toFixed(1) + '°' + (g.lon >= 0 ? 'E' : 'W');
  const level = (miss) => miss < 1 ? 2 : miss < 2 ? 1 : 0;
  const esc = (t) => t.replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  // ---------------------------------------------------------- selection
  function flyTo(lon, lat, zoom) {
    let d = ((lon - globe.lon + 540) % 360) - 180;
    state.anim = { lon0: globe.lon, lat0: globe.lat, z0: globe.zoom, dLon: d, lat1: Math.max(-80, Math.min(80, lat)), z1: zoom || globe.zoom, t0: performance.now(), dur: 900 };
    state.interacted = true;
  }

  function selectEvent(ev) {
    if (!ev) return;
    state.sel = { type: 'event', ev, orbitA: orbitPoints(ev.a, ev.tcaMs), orbitB: orbitPoints(ev.b, ev.tcaMs) };
    flyTo(ev.geo.lon, ev.geo.lat, Math.max(globe.zoom, 2.2));
    renderDetail(); state.listDirty = true;
  }
  function selectSat(i) {
    state.sel = { type: 'sat', i, orbit: orbitPoints(i, simNow()) };
    state.interacted = true;
    renderDetail(); state.listDirty = true;
  }
  function clearSelection() { state.sel = null; renderDetail(); state.listDirty = true; }
  function watch(ev) { ev = ev || (state.sel && state.sel.ev); if (!ev) return; if (!state.sel || state.sel.ev !== ev) selectEvent(ev); setClock(ev.tcaMs - 80000, 10); }
  function goLive() { setClock(Date.now(), 1); }

  function renderDetail() {
    const el = $('detail'), sel = state.sel;
    if (!sel) { el.hidden = true; el.innerHTML = ''; return; }
    el.hidden = false;
    if (sel.type === 'event') {
      const ev = sel.ev, A = state.sats[ev.a], B = state.sats[ev.b];
      el.innerHTML =
        '<div class="detail-head"><span class="pill lvl' + level(ev.miss) + '">Close pass</span><button class="x" id="closeDetail" aria-label="Close details">×</button></div>' +
        '<h2>' + esc(A.name) + ' <span class="times">×</span> ' + esc(B.name) + '</h2>' +
        '<dl>' +
        '<div><dt>Miss distance</dt><dd>' + fmtMiss(ev.miss) + '</dd></div>' +
        '<div><dt>Closing speed</dt><dd>' + ev.relSpeed.toFixed(1) + ' km/s</dd></div>' +
        '<div><dt>Closest approach</dt><dd>' + fmtUTC(ev.tcaMs) + ' UTC</dd></div>' +
        '<div><dt>Altitude</dt><dd>' + fmtInt(ev.geo.alt) + ' km</dd></div>' +
        '<div><dt>Over</dt><dd>' + fmtLatLon(ev.geo) + '</dd></div>' +
        '<div><dt>Separation now</dt><dd id="sepNow">…</dd></div>' +
        '</dl>' +
        '<div class="actions"><button class="btn primary" id="watchBtn">Watch this pass</button><button class="btn" id="liveBtn2">Back to live</button></div>';
      $('watchBtn').onclick = () => watch(ev);
      $('liveBtn2').onclick = goLive;
    } else {
      const s = state.sats[sel.i];
      const mine = state.screener ? state.screener.list().filter((e) => e.a === sel.i || e.b === sel.i) : [];
      el.innerHTML =
        '<div class="detail-head"><span class="pill">' + esc(s.regime) + ' · ' + esc(s.family) + '</span><button class="x" id="closeDetail" aria-label="Close details">×</button></div>' +
        '<h2>' + esc(s.name) + '</h2>' +
        '<dl>' +
        '<div><dt>NORAD ID</dt><dd>' + esc(s.norad) + '</dd></div>' +
        '<div><dt>Altitude</dt><dd>' + fmtInt(s.perigee) + ' – ' + fmtInt(s.apogee) + ' km</dd></div>' +
        '<div><dt>Inclination</dt><dd>' + s.inc.toFixed(1) + '°</dd></div>' +
        '<div><dt>Period</dt><dd>' + s.period.toFixed(1) + ' min</dd></div>' +
        '<div><dt>Speed now</dt><dd id="sepNow">…</dd></div>' +
        '<div><dt>Passes under 5 km</dt><dd>' + mine.length + ' found</dd></div>' +
        '</dl>';
    }
    $('closeDetail').onclick = clearSelection;
  }

  // ------------------------------------------------------------- panels
  function onEvent(ev) {
    ev.ecef = toEcef(ev.mid, gmstAt(ev.tcaMs));
    ev.geo = geodetic(ev.ecef);
    state.listDirty = true;
  }

  function renderPanels(ms) {
    const sc = state.screener, all = sc.list();
    // stats
    let under1 = 0, best = null;
    for (const e of all) { if (e.miss < 1) under1++; if (!best || e.miss < best.miss) best = e; }
    $('statAll').textContent = fmtInt(all.length);
    $('statOne').textContent = fmtInt(under1);
    const scannedS = Math.max(1, (sc.scannedToMs - sc.startMs) / 1000);
    $('statAllLab').textContent = sc.done ? 'passes closer than 5 km in the next 3 hours' : 'passes closer than 5 km found so far';
    $('statRate').textContent = all.length ? 'one every ' + (scannedS / all.length < 10 ? (scannedS / all.length).toFixed(1) : Math.round(scannedS / all.length)) + ' s' : 'screening…';
    if (best) {
      $('statBest').textContent = fmtMiss(best.miss);
      $('statBestSub').textContent = state.sats[best.a].name + ' × ' + state.sats[best.b].name + ' at ' + fmtUTC(best.tcaMs).substring(0, 5) + ' UTC';
      $('statBestBtn').onclick = () => selectEvent(best);
    }
    // progress
    const p = sc.progress;
    $('progFill').style.width = (p * 100).toFixed(1) + '%';
    $('progText').textContent = sc.done
      ? 'Screened 3 h ahead · ' + (sc.stats.propagations / 1e6).toFixed(1) + ' M propagations · ' + (sc.stats.pairsTested / 1e6).toFixed(0) + ' M pairs checked'
      : 'Screening the next 3 h · ' + Math.round(p * 100) + '%';

    // markers + list share the filter
    const pool = all.filter((e) => e.miss < state.maxMiss);
    state.shown = pool.filter((e) => e.tcaMs > ms - 60000);
    let rows = state.sort === 'soonest' ? state.shown.slice() : pool.slice().sort((x, y) => x.miss - y.miss);
    const total = rows.length; rows = rows.slice(0, 60);
    const selKey = state.sel && state.sel.type === 'event' ? state.sel.ev.key : -1;
    $('listCount').textContent = fmtInt(total) + (state.sort === 'soonest' ? ' upcoming' : ' in window');
    $('list').innerHTML = rows.length ? rows.map((e) => {
      const A = state.sats[e.a], B = state.sats[e.b];
      return '<li><button class="row lvl' + level(e.miss) + (e.key === selKey ? ' on' : '') + '" data-key="' + e.key + '">' +
        '<span class="miss">' + fmtMiss(e.miss) + '</span><span class="when">' + fmtIn(e.tcaMs - ms) + '</span>' +
        '<span class="names">' + esc(A.name) + ' × ' + esc(B.name) + '</span>' +
        '<span class="meta">' + e.relSpeed.toFixed(1) + ' km/s · ' + fmtInt(e.geo.alt) + ' km up · ' + fmtUTC(e.tcaMs) + '</span></button></li>';
    }).join('') : '<li class="empty">' + (sc.done ? 'No passes this close in the window.' : 'Screening…') + '</li>';

    renderHistogram(all);
  }

  const BAND0 = 300, BAND = 50, BANDS = 20;
  let satBands = null;
  function renderHistogram(all) {
    if (!satBands) {
      satBands = new Array(BANDS).fill(0);
      for (const s of state.sats) { const b = Math.floor((s.alt - BAND0) / BAND); if (b >= 0 && b < BANDS) satBands[b]++; }
    }
    const ev = new Array(BANDS).fill(0);
    for (const e of all) { const b = Math.floor((e.geo.alt - BAND0) / BAND); if (b >= 0 && b < BANDS) ev[b]++; }
    const mS = Math.max(...satBands), mE = Math.max(1, ...ev);
    $('hist').innerHTML = satBands.map((c, i) =>
      '<div class="col" title="' + (BAND0 + i * BAND) + '–' + (BAND0 + (i + 1) * BAND) + ' km: ' + fmtInt(c) + ' satellites, ' + fmtInt(ev[i]) + ' close passes">' +
      '<i class="up" style="height:' + (Math.sqrt(c / mS) * 100).toFixed(1) + '%"></i><i class="down" style="height:' + (Math.sqrt(ev[i] / mE) * 100).toFixed(1) + '%"></i></div>').join('');
    $('histMaxS').textContent = fmtInt(mS);
    $('histMaxE').textContent = fmtInt(mE);
  }

  // -------------------------------------------------------------- frame
  let lastPanels = 0, lastFrame = performance.now();
  function frame() {
    const t = performance.now(), dt = Math.min(100, t - lastFrame); lastFrame = t;
    const ms = simNow(), gmst = gmstAt(ms);

    // camera
    if (state.anim) {
      const a = state.anim, u = Math.min(1, (t - a.t0) / a.dur), k = 1 - Math.pow(1 - u, 3);
      globe.lon = a.lon0 + a.dLon * k; globe.lat = a.lat0 + (a.lat1 - a.lat0) * k; globe.zoom = a.z0 + (a.z1 - a.z0) * k;
      if (u >= 1) state.anim = null;
    } else if (!state.interacted && !reducedMotion) {
      globe.lon -= dt * 0.0022;
    }

    // positions
    const s = updateSnapshots(ms);
    const trailMs = state.clock.speed >= 60 ? 60000 : state.clock.speed >= 10 ? 30000 : 20000;
    interpolate(s, ms - trailMs, state.trailBuf);
    globe.projectAll(state.trailBuf, state.n, gmstAt(ms - trailMs));
    state.tx.set(globe.sx); state.ty.set(globe.sy);
    interpolate(s, ms, state.cur);
    globe.projectAll(state.cur, state.n, gmst);

    // draw
    globe.begin();
    globe.drawEarth(NM_LAND, sunPoint(ms));
    globe.drawSatellites(state.groups, [state.tx, state.ty]);
    const b = globe.basis(), phase = (t % 1400) / 1400;
    for (const e of state.shown) {
      const p = globe.project(e.ecef[0], e.ecef[1], e.ecef[2], b);
      if (!p[2] || !p[3]) continue;
      const dtE = e.tcaMs - ms;
      if (dtE < -60000) continue;
      globe.drawEventMarker(p[0], p[1], level(e.miss), phase, Math.abs(dtE) < 120000);
    }
    drawSelection(ms, gmst, b);
    if (state.hover >= 0 && globe.vis[state.hover] === 2) {
      const g = globe.ctx; g.strokeStyle = COLORS.select; g.lineWidth = 1.2;
      g.beginPath(); g.arc(globe.sx[state.hover], globe.sy[state.hover], 6, 0, 6.2832); g.stroke();
    }

    // background work: the conjunction screen gets what is left of the frame
    if (!state.screener.done) { state.screener.run(9); state.listDirty = true; }

    if (t - lastPanels > (state.listDirty ? 450 : 1000)) {
      lastPanels = t; state.listDirty = false;
      renderPanels(ms);
      $('clock').textContent = new Date(ms).toISOString().substring(0, 19).replace('T', ' ') + ' UTC';
      const live = isLive();
      $('liveBtn').classList.toggle('on', live);
      $('liveBtn').textContent = live ? 'Live' : 'Go live';
    }
    requestAnimationFrame(frame);
  }

  function drawSelection(ms, gmst, b) {
    const sel = state.sel; if (!sel) return;
    if (sel.type === 'event') {
      const ev = sel.ev;
      globe.drawOrbit(sel.orbitA, gmst, 'rgba(255,224,138,0.75)');
      globe.drawOrbit(sel.orbitB, gmst, 'rgba(255,93,71,0.8)');
      const pa = exact(ev.a, ms), pb = exact(ev.b, ms);
      if (!pa || !pb) return;
      const ea = toEcef(pa, gmst), eb = toEcef(pb, gmst);
      const A = globe.project(ea[0], ea[1], ea[2], b), B = globe.project(eb[0], eb[1], eb[2], b);
      const sep = Math.hypot(pa[0] - pb[0], pa[1] - pb[1], pa[2] - pb[2]);
      if (A[2] && B[2] && sep < 4000) globe.drawLink(A[0], A[1], B[0], B[1], 'rgba(233,238,247,0.6)');
      const right = A[0] < B[0];
      if (A[2]) globe.drawLabelledDot(A[0], A[1], state.sats[ev.a].name, COLORS.select, right ? 'right' : 'left');
      if (B[2]) globe.drawLabelledDot(B[0], B[1], state.sats[ev.b].name, COLORS.alert, right ? 'left' : 'right');
      const el = $('sepNow'); if (el) el.textContent = sep < 10 ? sep.toFixed(2) + ' km' : fmtInt(sep) + ' km';
    } else {
      globe.drawOrbit(sel.orbit, gmst, 'rgba(255,224,138,0.75)');
      const p = exact(sel.i, ms); if (!p) return;
      const e = toEcef(p, gmst), P = globe.project(e[0], e[1], e[2], b);
      if (P[2]) globe.drawLabelledDot(P[0], P[1], state.sats[sel.i].name, COLORS.select);
      const el = $('sepNow'); if (el) el.textContent = Math.hypot(p[3].x, p[3].y, p[3].z).toFixed(2) + ' km/s';
    }
  }

  // -------------------------------------------------------------- input
  const reducedMotion = root.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;

  function nearestSat(x, y, maxPx) {
    let best = -1, bd = maxPx * maxPx;
    const sx = globe.sx, sy = globe.sy, vis = globe.vis;
    for (let i = 0; i < state.n; i++) {
      if (vis[i] !== 2) continue;
      const dx = sx[i] - x, dy = sy[i] - y, d = dx * dx + dy * dy;
      if (d < bd) { bd = d; best = i; }
    }
    return best;
  }
  function nearestEvent(x, y, maxPx) {
    let best = null, bd = maxPx * maxPx; const b = globe.basis();
    for (const e of state.shown) {
      if (level(e.miss) === 0) continue;
      const p = globe.project(e.ecef[0], e.ecef[1], e.ecef[2], b);
      if (!p[2] || !p[3]) continue;
      const d = (p[0] - x) ** 2 + (p[1] - y) ** 2;
      if (d < bd) { bd = d; best = e; }
    }
    return best;
  }

  function bindInput(canvas) {
    const pts = new Map(); let moved = 0, pinch = 0;
    const tip = $('tip');
    const local = (e) => { const r = canvas.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; };
    canvas.addEventListener('pointerdown', (e) => {
      canvas.setPointerCapture(e.pointerId); pts.set(e.pointerId, [e.clientX, e.clientY]); moved = 0;
      if (pts.size === 2) { const [p, q] = [...pts.values()]; pinch = Math.hypot(p[0] - q[0], p[1] - q[1]); }
    });
    canvas.addEventListener('pointermove', (e) => {
      const [x, y] = local(e);
      if (pts.has(e.pointerId)) {
        const prev = pts.get(e.pointerId), dx = e.clientX - prev[0], dy = e.clientY - prev[1];
        pts.set(e.pointerId, [e.clientX, e.clientY]);
        if (pts.size === 2) {
          const [p, q] = [...pts.values()], d = Math.hypot(p[0] - q[0], p[1] - q[1]);
          if (pinch) setZoom(globe.zoom * d / pinch); pinch = d; moved = 99;
        } else {
          moved += Math.abs(dx) + Math.abs(dy);
          const k = 180 / Math.PI / globe.R;
          globe.lon -= dx * k; globe.lat = Math.max(-85, Math.min(85, globe.lat + dy * k));
          state.anim = null; state.interacted = true;
        }
        tip.hidden = true; state.hover = -1;
        return;
      }
      if (e.pointerType === 'touch') return;
      const ev = nearestEvent(x, y, 10);
      const i = ev ? -1 : nearestSat(x, y, 9);
      state.hover = i;
      if (ev || i >= 0) {
        tip.hidden = false;
        tip.innerHTML = ev
          ? '<b>' + fmtMiss(ev.miss) + '</b> ' + esc(state.sats[ev.a].name) + ' × ' + esc(state.sats[ev.b].name)
          : '<b>' + esc(state.sats[i].name) + '</b> ' + fmtInt(state.sats[i].alt) + ' km';
        tip.style.transform = 'translate(' + Math.min(globe.w - 260, x + 14) + 'px,' + (y + 14) + 'px)';
        canvas.style.cursor = 'pointer';
      } else { tip.hidden = true; canvas.style.cursor = 'grab'; }
    });
    const up = (e) => {
      const had = pts.delete(e.pointerId); pinch = 0;
      if (!had || moved > 6 || e.type === 'pointercancel') return;
      const [x, y] = local(e);
      const ev = nearestEvent(x, y, 14);
      if (ev) return selectEvent(ev);
      const i = nearestSat(x, y, 12);
      if (i >= 0) selectSat(i); else if (state.sel) clearSelection();
    };
    canvas.addEventListener('pointerup', up); canvas.addEventListener('pointercancel', up);
    canvas.addEventListener('pointerleave', () => { tip.hidden = true; state.hover = -1; });
    canvas.addEventListener('wheel', (e) => { e.preventDefault(); setZoom(globe.zoom * Math.exp(-e.deltaY * 0.0015)); }, { passive: false });
  }
  function setZoom(z) { globe.zoom = Math.max(0.4, Math.min(9, z)); state.anim = null; state.interacted = true; }

  function layout() {
    globe.resize();
    const wide = matchMedia('(min-width: 900px)').matches;
    globe.offsetX = wide ? ($('left').offsetWidth - $('right').offsetWidth) / 2 : 0;
  }

  // --------------------------------------------------------------- boot
  async function loadCatalogue() {
    // Self-hosted copies get fresh elements straight from CelesTrak. Where the
    // network is locked down the bundled snapshot is used instead.
    try {
      const ctl = new AbortController(); const timer = setTimeout(() => ctl.abort(), 3500);
      const res = await fetch(LIVE_SOURCE, { signal: ctl.signal }); clearTimeout(timer);
      const text = await res.text();
      if (res.ok && text.split('\n').length > 3000 && text.indexOf('\n1 ') > 0) {
        state.source = 'live';
        return text.replace(/\r/g, '');
      }
    } catch (e) { /* fall through to the snapshot */ }
    return root.NM_TLE;
  }

  async function boot() {
    const text = await loadCatalogue();
    const cat = parseCatalogue(text);
    state.sats = cat.sats; state.n = cat.sats.length; state.epochMs = cat.epochMs;
    const g = { starlink: [], leo: [], high: [] };
    cat.sats.forEach((s, i) => (s.family === 'Starlink' ? g.starlink : s.regime === 'LEO' ? g.leo : g.high).push(i));
    state.groups = { starlink: Int32Array.from(g.starlink), leo: Int32Array.from(g.leo), high: Int32Array.from(g.high) };
    state.cur = new Float32Array(state.n * 3); state.trailBuf = new Float32Array(state.n * 3);
    state.tx = new Float32Array(state.n); state.ty = new Float32Array(state.n);

    $('statSats').textContent = fmtInt(state.n);
    $('legStarlink').textContent = fmtInt(g.starlink.length);
    $('legLeo').textContent = fmtInt(g.leo.length);
    $('legHigh').textContent = fmtInt(g.high.length);
    const ageDays = (Date.now() - state.epochMs) / 864e5;
    $('source').textContent = 'Orbital elements: CelesTrak, ' + (state.source === 'live' ? 'fetched just now' : 'snapshot of ' + new Date(state.epochMs).toISOString().substring(0, 10)) +
      (ageDays > 6 ? '. This snapshot is ' + Math.round(ageDays) + ' days old, so positions have drifted.' : '.');

    globe = new NM.Globe($('globe'));
    layout();
    root.addEventListener('resize', layout);
    bindInput($('globe'));

    state.screener = new Screener(state.sats, { startMs: Date.now(), windowS: WINDOW_S, threshold: THRESHOLD_KM, onEvent });

    document.querySelectorAll('[data-speed]').forEach((b) => b.onclick = () => setClock(simNow(), +b.dataset.speed));
    document.querySelectorAll('[data-miss]').forEach((b) => b.onclick = () => {
      state.maxMiss = +b.dataset.miss; state.listDirty = true;
      document.querySelectorAll('[data-miss]').forEach((o) => o.setAttribute('aria-pressed', String(o === b)));
    });
    document.querySelectorAll('[data-sort]').forEach((b) => b.onclick = () => {
      state.sort = b.dataset.sort; state.listDirty = true;
      document.querySelectorAll('[data-sort]').forEach((o) => o.setAttribute('aria-pressed', String(o === b)));
    });
    $('liveBtn').onclick = goLive;
    $('zoomIn').onclick = () => setZoom(globe.zoom * 1.35);
    $('zoomOut').onclick = () => setZoom(globe.zoom / 1.35);
    $('list').addEventListener('click', (e) => {
      const row = e.target.closest('[data-key]'); if (!row) return;
      selectEvent(state.screener.events.get(+row.dataset.key));
    });
    document.body.classList.add('ready');
    requestAnimationFrame(frame);
  }

  NM.app = { state, selectEvent, selectSat, clearSelection, watch, goLive, setClock, simNow, get globe() { return globe; } };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})(window);
