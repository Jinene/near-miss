/* Near Miss — catalogue loading.
 *
 * Parses a CelesTrak three-line element (3LE) file into SGP4 satellite
 * records and derives the handful of orbit facts the UI needs
 * (mean altitude, regime, operator family).
 */
(function (root) {
  'use strict';
  const sat = root.satellite || (typeof require === 'function' ? require('satellite.js') : null);

  const MU = 398600.4418;      // km^3 / s^2
  const RE = 6378.137;         // km, WGS-84 equatorial radius
  const TWO_PI = Math.PI * 2;

  /** Orbit regime from mean altitude and eccentricity. */
  function regimeOf(altKm, ecc) {
    if (ecc > 0.25) return 'HEO';
    if (altKm < 2000) return 'LEO';
    if (altKm > 35286 && altKm < 36286) return 'GEO';
    return 'MEO';
  }

  /** Collapse object names into operator families, e.g. "STARLINK-1234" -> "Starlink". */
  const FAMILIES = [
    [/^STARLINK/, 'Starlink'], [/^ONEWEB/, 'OneWeb'], [/^KUIPER/, 'Kuiper'],
    [/^(QIANFAN|G60)/, 'Qianfan'], [/^(GUOWANG|HULIANWANG)/, 'Guowang'],
    [/^IRIDIUM/, 'Iridium'], [/^(FLOCK|DOVE|SKYSAT|PELICAN)/, 'Planet'],
    [/^LEMUR/, 'Spire'], [/^(NAVSTAR|GPS)/, 'GPS'], [/^(GSAT0|GALILEO)/, 'Galileo'],
    [/^BEIDOU/, 'BeiDou'], [/^COSMOS/, 'Cosmos'], [/^YAOGAN/, 'Yaogan'],
    [/^(ISS|CSS|TIANHE|WENTIAN|MENGTIAN|PROGRESS|SOYUZ|CREW DRAGON|CARGO DRAGON|CYGNUS|SHENZHOU|TIANZHOU)/, 'Crewed'],
  ];
  function familyOf(name) {
    for (const [re, fam] of FAMILIES) if (re.test(name)) return fam;
    return 'Other';
  }

  /**
   * @param {string} text  3LE text: name line, line 1, line 2, repeated.
   * @returns {{sats: Array, epochMs: number}}
   */
  function parseCatalogue(text) {
    const lines = text.split('\n');
    const sats = [];
    const epochs = [];
    for (let i = 0; i + 2 < lines.length; i += 3) {
      const name = lines[i].trim();
      const l1 = lines[i + 1], l2 = lines[i + 2];
      if (l1[0] !== '1' || l2[0] !== '2') { i -= 2; continue; }   // resync on a malformed block
      let rec;
      try { rec = sat.twoline2satrec(l1, l2); } catch (e) { continue; }
      if (!rec || rec.error) continue;
      const n = rec.no / 60;                               // rad / s
      const a = Math.cbrt(MU / (n * n));                   // semi-major axis, km
      const alt = a - RE;
      if (!(alt > 120) || !isFinite(alt)) continue;        // decayed or broken element set
      const epochMs = (rec.jdsatepoch - 2440587.5) * 86400000;
      epochs.push(epochMs);
      sats.push({
        id: sats.length,
        name,
        norad: l1.substring(2, 7).trim(),
        rec,
        alt,                                               // mean altitude, km
        perigee: a * (1 - rec.ecco) - RE,
        apogee: a * (1 + rec.ecco) - RE,
        inc: rec.inclo * 180 / Math.PI,
        period: TWO_PI / n / 60,                           // minutes
        regime: regimeOf(alt, rec.ecco),
        family: familyOf(name),
      });
    }
    epochs.sort((x, y) => x - y);
    return { sats, epochMs: epochs[epochs.length >> 1] || Date.now() };
  }

  const api = { parseCatalogue, regimeOf, familyOf, RE, MU };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.NM = Object.assign(root.NM || {}, { catalog: api });
})(typeof window !== 'undefined' ? window : globalThis);
