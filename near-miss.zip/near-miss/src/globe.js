/* Near Miss — canvas renderer.
 *
 * Draws the Earth with an orthographic projection (d3-geo handles horizon
 * clipping of the coastlines) and projects every satellite by hand, because
 * 16,000 points per frame is too many to push through a generic geo path.
 *
 * Frames of reference:
 *   TEME  inertial frame SGP4 works in. Positions are stored in it.
 *   ECEF  Earth-fixed frame. TEME rotated about Z by Greenwich sidereal time.
 *   view  ECEF dotted with the east / north / toward-viewer unit vectors of
 *         the point at the centre of the screen.
 */
(function (root) {
  'use strict';
  const RE = 6378.137;
  const DEG = Math.PI / 180;

  const COLORS = {
    space: '#060912',
    oceanA: '#0e2038', oceanB: '#081425',
    land: '#24405e', landEdge: '#3c5f85',
    grid: 'rgba(140,175,215,0.07)',
    night: 'rgba(3,6,14,0.5)',
    // satellite classes: [front colour, behind-the-limb colour]
    starlink: ['rgba(126,170,222,0.85)', 'rgba(126,170,222,0.25)'],
    leo: ['rgba(240,236,224,0.95)', 'rgba(240,236,224,0.3)'],
    high: ['rgba(168,150,255,0.95)', 'rgba(168,150,255,0.4)'],
    alert: '#ff5d47', alertSoft: 'rgba(255,93,71,0.28)',
    warn: '#ffb648',
    select: '#ffe08a',
    text: '#e9eef7',
  };

  class Globe {
    constructor(canvas) {
      this.canvas = canvas;
      this.ctx = canvas.getContext('2d');
      this.lon = 12; this.lat = 18;      // centre of view, degrees
      this.zoom = 1;
      this.w = 0; this.h = 0; this.dpr = 1;
      this.offsetX = 0;                  // shifts the globe clear of the side panels
      this.proj = d3.geoOrthographic().clipAngle(90).precision(0.6);
      this.path = d3.geoPath(this.proj, this.ctx);
      this.graticule = d3.geoGraticule10();
      this.nightCircle = d3.geoCircle().radius(90).precision(3);
      this.stars = null;
      this.sx = new Float32Array(0); this.sy = new Float32Array(0); this.vis = new Uint8Array(0);
      this.resize();
    }

    resize() {
      const r = this.canvas.getBoundingClientRect();
      this.dpr = Math.min(2, root.devicePixelRatio || 1);
      this.w = Math.max(1, r.width); this.h = Math.max(1, r.height);
      this.canvas.width = Math.round(this.w * this.dpr);
      this.canvas.height = Math.round(this.h * this.dpr);
      this._makeStars();
    }

    get cx() { return this.w / 2 + this.offsetX; }
    get cy() { return this.h / 2; }
    /** Earth radius in CSS pixels. */
    get R() { return Math.min(this.w, this.h) * 0.36 * this.zoom; }

    _makeStars() {
      const c = document.createElement('canvas');
      c.width = this.canvas.width; c.height = this.canvas.height;
      const g = c.getContext('2d');
      let seed = 7;
      const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
      const count = Math.round(this.w * this.h / 2600);
      for (let i = 0; i < count; i++) {
        const a = 0.15 + rnd() * 0.5, s = (rnd() < 0.08 ? 1.6 : 0.9) * this.dpr;
        g.fillStyle = 'rgba(200,215,240,' + a.toFixed(2) + ')';
        g.fillRect(rnd() * c.width, rnd() * c.height, s, s);
      }
      this.stars = c;
    }

    /** Unit vectors of the view, in ECEF. */
    basis() {
      const l = this.lon * DEG, p = this.lat * DEG;
      const cl = Math.cos(l), sl = Math.sin(l), cp = Math.cos(p), sp = Math.sin(p);
      return { e: [-sl, cl, 0], n: [-sp * cl, -sp * sl, cp], v: [cp * cl, cp * sl, sp] };
    }

    /** Project one ECEF point (km). Returns [x, y, visible, inFront]. */
    project(x, y, z, b) {
      b = b || this.basis();
      const k = this.R / RE;
      const pe = x * b.e[0] + y * b.e[1];
      const pn = x * b.n[0] + y * b.n[1] + z * b.n[2];
      const pv = x * b.v[0] + y * b.v[1] + z * b.v[2];
      const hidden = pv < 0 && pe * pe + pn * pn < RE * RE;
      return [this.cx + pe * k, this.cy - pn * k, !hidden, pv >= 0];
    }

    /**
     * Project a packed TEME buffer for all satellites.
     * vis: 0 hidden behind Earth, 1 behind the limb plane, 2 in front.
     */
    projectAll(eci, n, gmst) {
      if (this.sx.length !== n) { this.sx = new Float32Array(n); this.sy = new Float32Array(n); this.vis = new Uint8Array(n); }
      const b = this.basis(), k = this.R / RE, cx = this.cx, cy = this.cy;
      const cg = Math.cos(gmst), sg = Math.sin(gmst);
      const e0 = b.e[0], e1 = b.e[1], n0 = b.n[0], n1 = b.n[1], n2 = b.n[2], v0 = b.v[0], v1 = b.v[1], v2 = b.v[2];
      const sx = this.sx, sy = this.sy, vis = this.vis, R2 = RE * RE;
      for (let i = 0, j = 0; i < n; i++, j += 3) {
        const X = eci[j], Y = eci[j + 1], z = eci[j + 2];
        const x = X * cg + Y * sg, y = -X * sg + Y * cg;
        const pe = x * e0 + y * e1, pn = x * n0 + y * n1 + z * n2, pv = x * v0 + y * v1 + z * v2;
        sx[i] = cx + pe * k; sy[i] = cy - pn * k;
        vis[i] = pv >= 0 ? 2 : (pe * pe + pn * pn < R2 ? 0 : 1);
      }
    }

    begin() {
      const g = this.ctx;
      g.setTransform(1, 0, 0, 1, 0, 0);
      g.fillStyle = COLORS.space;
      g.fillRect(0, 0, this.canvas.width, this.canvas.height);
      if (this.stars) g.drawImage(this.stars, 0, 0);
      g.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    }

    /** @param sun {lon, lat} sub-solar point, degrees */
    drawEarth(land, sun) {
      const g = this.ctx, R = this.R, cx = this.cx, cy = this.cy;
      // atmosphere
      const halo = g.createRadialGradient(cx, cy, R * 0.98, cx, cy, R * 1.12);
      halo.addColorStop(0, 'rgba(90,150,235,0.34)'); halo.addColorStop(1, 'rgba(90,150,235,0)');
      g.fillStyle = halo; g.beginPath(); g.arc(cx, cy, R * 1.12, 0, 6.2832); g.fill();
      // ocean
      const sea = g.createRadialGradient(cx - R * 0.3, cy - R * 0.35, R * 0.1, cx, cy, R);
      sea.addColorStop(0, COLORS.oceanA); sea.addColorStop(1, COLORS.oceanB);
      g.fillStyle = sea; g.beginPath(); g.arc(cx, cy, R, 0, 6.2832); g.fill();

      this.proj.translate([cx, cy]).scale(R).rotate([-this.lon, -this.lat]);
      g.beginPath(); this.path(this.graticule); g.strokeStyle = COLORS.grid; g.lineWidth = 1; g.stroke();
      g.beginPath(); this.path(land); g.fillStyle = COLORS.land; g.fill();
      g.strokeStyle = COLORS.landEdge; g.lineWidth = 0.6; g.stroke();
      // night side
      g.beginPath(); this.path(this.nightCircle.center([sun.lon + 180, -sun.lat])());
      g.fillStyle = COLORS.night; g.fill();
      // limb
      g.beginPath(); g.arc(cx, cy, R, 0, 6.2832); g.strokeStyle = 'rgba(120,170,240,0.5)'; g.lineWidth = 1; g.stroke();
    }

    /**
     * @param groups  {starlink: Int32Array, leo: Int32Array, high: Int32Array}
     * @param trail   optional Float32Array pair [tx, ty] of earlier screen positions
     */
    drawSatellites(groups, trail) {
      const g = this.ctx, sx = this.sx, sy = this.sy, vis = this.vis;
      const size = Math.max(1.3, Math.min(2.6, 1.2 + this.zoom * 0.35));
      const h = size / 2;
      for (const name of ['starlink', 'leo', 'high']) {
        const idx = groups[name], col = COLORS[name];
        const s = name === 'starlink' ? size : size * 1.15, hh = s / 2;
        for (let pass = 1; pass <= 2; pass++) {
          if (trail && pass === 2) {
            g.beginPath();
            for (let q = 0; q < idx.length; q++) {
              const i = idx[q]; if (vis[i] !== 2) continue;
              g.moveTo(trail[0][i], trail[1][i]); g.lineTo(sx[i], sy[i]);
            }
            g.strokeStyle = col[1]; g.lineWidth = 1; g.stroke();
          }
          g.fillStyle = col[pass - 1 ? 0 : 1];
          for (let q = 0; q < idx.length; q++) {
            const i = idx[q]; if (vis[i] !== pass) continue;
            g.fillRect(sx[i] - hh, sy[i] - hh, s, s);
          }
        }
      }
      void h;
    }

    /** A ring marking where a close pass happens. phase 0..1 animates the pulse. */
    drawEventMarker(x, y, level, phase, active) {
      const g = this.ctx;
      const col = level === 2 ? COLORS.alert : level === 1 ? COLORS.warn : 'rgba(255,182,72,0.55)';
      if (level === 0) { g.fillStyle = col; g.fillRect(x - 1, y - 1, 2, 2); return; }
      g.strokeStyle = col; g.lineWidth = 1.4;
      g.beginPath(); g.arc(x, y, 4, 0, 6.2832); g.stroke();
      if (active) {
        g.globalAlpha = 1 - phase;
        g.beginPath(); g.arc(x, y, 4 + phase * 22, 0, 6.2832); g.stroke();
        g.globalAlpha = 1;
        g.fillStyle = col; g.beginPath(); g.arc(x, y, 2, 0, 6.2832); g.fill();
      }
    }

    /** Orbit ring from TEME sample points, hidden where the Earth is in the way. */
    drawOrbit(pts, gmst, color) {
      const g = this.ctx, b = this.basis();
      const cg = Math.cos(gmst), sg = Math.sin(gmst);
      g.strokeStyle = color; g.lineWidth = 1.3; g.beginPath();
      let pen = false;
      for (let i = 0; i < pts.length; i += 3) {
        const x = pts[i] * cg + pts[i + 1] * sg, y = -pts[i] * sg + pts[i + 1] * cg;
        const p = this.project(x, y, pts[i + 2], b);
        if (!p[2]) { pen = false; continue; }
        if (pen) g.lineTo(p[0], p[1]); else { g.moveTo(p[0], p[1]); pen = true; }
      }
      g.stroke();
    }

    drawLabelledDot(x, y, label, color, align) {
      const g = this.ctx;
      g.fillStyle = color; g.beginPath(); g.arc(x, y, 4, 0, 6.2832); g.fill();
      g.strokeStyle = 'rgba(6,9,18,0.9)'; g.lineWidth = 1.5; g.stroke();
      g.font = '600 11px "JetBrains Mono", ui-monospace, monospace';
      g.textAlign = align || 'left'; g.textBaseline = 'middle';
      const tx = x + (align === 'right' ? -9 : 9);
      g.lineWidth = 3; g.strokeStyle = 'rgba(6,9,18,0.85)'; g.strokeText(label, tx, y);
      g.fillStyle = COLORS.text; g.fillText(label, tx, y);
    }

    drawLink(x1, y1, x2, y2, color) {
      const g = this.ctx;
      g.setLineDash([4, 4]); g.strokeStyle = color; g.lineWidth = 1.2;
      g.beginPath(); g.moveTo(x1, y1); g.lineTo(x2, y2); g.stroke(); g.setLineDash([]);
    }
  }

  root.NM = Object.assign(root.NM || {}, { Globe, COLORS });
})(window);
