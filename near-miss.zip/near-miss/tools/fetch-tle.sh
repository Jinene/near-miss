#!/bin/sh
# Refresh the bundled catalogue snapshot from CelesTrak.
#
# CelesTrak asks that a group is downloaded no more than once every two hours;
# it answers repeat requests with a short text notice instead of element sets,
# so the script refuses to overwrite the snapshot unless it gets real 3LE data.
set -eu
cd "$(dirname "$0")/.."

URL='https://celestrak.org/NORAD/elements/gp.php?GROUP=active&FORMAT=tle'
TMP="$(mktemp)"
trap 'rm -f "$TMP"' EXIT

curl -fsSL --max-time 60 "$URL" | tr -d '\r' | sed 's/[[:space:]]*$//' | grep -v '^$' > "$TMP"

LINES=$(wc -l < "$TMP")
if [ "$LINES" -lt 9000 ] || ! sed -n '2p' "$TMP" | grep -q '^1 '; then
  echo "Not a TLE file ($LINES lines). CelesTrak may be rate limiting; try again later." >&2
  exit 1
fi

cp "$TMP" data/active.txt
{
  echo '/* CelesTrak "active" GP catalogue snapshot (3LE). Refresh with tools/fetch-tle.sh */'
  printf 'window.NM_TLE=`'
  cat "$TMP"
  echo '`;'
} > data/tle-snapshot.js

echo "Updated: $((LINES / 3)) objects."
