/* Cross-checks the grid-based screener against a brute-force all-pairs search.
 * Run with: npm test
 */
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const path = require('path');
const satellite = require('satellite.js');
const { parseCatalogue } = require('../src/catalog.js');
const { Screener } = require('../src/screening.js');

const text = fs.readFileSync(path.join(__dirname, '..', 'data', 'active.txt'), 'utf8');
const cat = parseCatalogue(text);
const START = cat.epochMs + 6 * 3600 * 1000;

test('catalogue parses and classifies', () => {
  assert.ok(cat.sats.length > 10000, 'expected a full active catalogue');
  const iss = cat.sats.find((s) => s.name.startsWith('ISS (ZARYA)'));
  assert.ok(iss, 'ISS present');
  assert.strictEqual(iss.regime, 'LEO');
  assert.ok(iss.alt > 370 && iss.alt < 460, 'ISS altitude ' + iss.alt);
  assert.ok(Math.abs(iss.inc - 51.6) < 0.2);
});

test('screener matches brute force on a 1,500-object subset', () => {
  // Every 7th object in the busiest shell keeps brute force affordable.
  const subset = cat.sats.filter((s) => s.alt > 430 && s.alt < 570).filter((_, i) => i % 7 === 0).slice(0, 1500);
  const WINDOW = 600, THRESH = 5;

  const sc = new Screener(subset, { startMs: START, windowS: WINDOW, threshold: THRESH });
  while (!sc.run(1000));
  const fast = new Map(sc.list().map((e) => [e.a + ':' + e.b, e]));

  // Brute force: every pair, every second, straight-line closest approach inside the second.
  const n = subset.length, P = new Float64Array(n * 3), V = new Float64Array(n * 3);
  const brute = new Map();
  for (let t = 0; t < WINDOW; t++) {
    const ms = START + t * 1000;
    for (let i = 0; i < n; i++) {
      const pv = satellite.sgp4(subset[i].rec, Screener.tsince(subset[i].rec, ms));
      P.set([pv.position.x, pv.position.y, pv.position.z], i * 3);
      V.set([pv.velocity.x, pv.velocity.y, pv.velocity.z], i * 3);
    }
    for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) {
      const a = i * 3, b = j * 3;
      const rx = P[b] - P[a], ry = P[b + 1] - P[a + 1], rz = P[b + 2] - P[a + 2];
      if (Math.abs(rx) > 25 || Math.abs(ry) > 25 || Math.abs(rz) > 25) continue;
      const vx = V[b] - V[a], vy = V[b + 1] - V[a + 1], vz = V[b + 2] - V[a + 2];
      const vv = vx * vx + vy * vy + vz * vz;
      if (Math.sqrt(vv) < 0.1) continue;
      const tc = Math.min(1, Math.max(0, -(rx * vx + ry * vy + rz * vz) / vv));
      const d = Math.hypot(rx + vx * tc, ry + vy * tc, rz + vz * tc);
      const key = i + ':' + j;
      if (d < THRESH && (!brute.has(key) || brute.get(key) > d)) brute.set(key, d);
    }
  }

  assert.ok(brute.size > 0, 'subset should contain at least one close pass');
  for (const [key, d] of brute) {
    if (d > THRESH - 0.05) continue;                      // right on the threshold: either answer is fine
    assert.ok(fast.has(key), 'screener missed pair ' + key + ' at ' + d.toFixed(3) + ' km');
    assert.ok(Math.abs(fast.get(key).miss - d) < 0.02, 'miss distance differs for ' + key);
  }
  for (const [key, e] of fast) {
    if (e.miss > THRESH - 0.05) continue;
    assert.ok(brute.has(key), 'screener reported a pass brute force did not find: ' + key);
  }
  console.log('    ' + brute.size + ' passes, identical in both searches');
});
